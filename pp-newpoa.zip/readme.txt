# take care of dependencies
# compile
make

# create extendedx2 clusters
python3 extend.py [ref] [sfs] [reconstructed.bam] > [clusters.bed]

# call svs from clusters (this will creare a prefix.sam and prefix.vcf)
./main [ref] [clusters.bed] [prefix]

# clean clusters
python3 cluster_svs.py [prefix.vcf] > [clean.vcf]